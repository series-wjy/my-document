package com.wjy.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.wjy.service.DemoHessianService;
import com.wjy.service.DemoService;
import com.wjy.vo.FileInfoVo;
import com.wjy.vo.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
@RequestMapping("/files")
public class ConsumerController {
	private static final Logger log = LoggerFactory.getLogger(ConsumerController.class.getName());
	@Reference(version = "1.0.0",check = true)
	private DemoService demoService;
	@Reference(version = "1.0.0",check = true)
	private DemoHessianService demoHessianService;
	
	@RequestMapping(value="/list",method= RequestMethod.GET)
	@ResponseBody
	public Result<List<FileInfoVo>> list() {
		List<FileInfoVo> list = demoService.findAllBook(null);
		return Result.success(list, list.size());
	}
	
	 /**
	 * 测试上传并保存文件
	 * @return
	 */
//	@RequestMapping(value="/testSaveFile")
//	@ResponseBody
//	public Result<String> testSaveFile(@RequestParam("file") MultipartFile file) {
//		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+file.getOriginalFilename()+"<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
//		try {
//			String fileMD5 = demoHessianService.testSaveFile(file.getOriginalFilename(),file.getInputStream());
//			return Result.success("文件保存成功",fileMD5);
//		} catch (IOException e) {
//			log.error("查询失败："+e.getMessage());
//			e.printStackTrace();
//		}
//
//		return Result.failed();
//	}

	/**
	 * 测试上传并保存文件
	 * @return
	 */
	@RequestMapping(value="/testSaveFile2", method= RequestMethod.GET)
	@ResponseBody
	public Result<String> testSaveFile() {
		LocalDateTime start = LocalDateTime.now();
		System.out.println(start.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + "：>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>文件传送开始<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
		try {
			File file = new File("e:\\download\\resource.zip");
			String fileMD5 = demoHessianService.testSaveFile(file.getName(), new FileInputStream(file));
			LocalDateTime end = LocalDateTime.now();
			System.out.println(start.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + "：>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>文件传送结束：" + Duration.between(start, end).toMillis() + "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
			return Result.success("文件保存成功",fileMD5);
		} catch (IOException e) {
			log.error("查询失败："+e.getMessage());
			e.printStackTrace();
		}

		return Result.failed();
	}

    /**
     * 测试获取文件
     * @return
     */
	@RequestMapping(value="/testGetFile",method= RequestMethod.GET)
    public void testGetFile(HttpServletResponse response) {
        response.setContentType("text/html;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=new.jpg");
        byte[] buffer = new byte[1024];
        int len = 0;
        try {
            InputStream nis = demoHessianService.testGetFile("");
            OutputStream nos = response.getOutputStream();
            while((len=nis.read(buffer))!=-1) {
                nos.write(buffer, 0, len);
            }
            nis.close();
        } catch (Exception e) {
            e.printStackTrace();
            log.error("获取文件失败: "+e.getMessage());
        }
    }
	
	@RequestMapping(value="/testMe",method= RequestMethod.GET)
	@ResponseBody
	public Result<String> testMe() {
//		String str = demoService.testMe(null);
		return Result.success("成功","str");
	}

}
