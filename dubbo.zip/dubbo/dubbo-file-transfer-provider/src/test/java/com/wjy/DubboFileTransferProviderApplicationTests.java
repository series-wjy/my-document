package com.wjy;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DubboFileTransferProviderApplicationTests {

    @Test
    void contextLoads() {
    }

}
