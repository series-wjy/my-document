package com.wjy.service;

import java.io.InputStream;

public interface DemoHessianService {
    
    String testSaveFile(String fileName, InputStream nis);
    
    InputStream testGetFile(String fileId);
    
}
