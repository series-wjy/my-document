package com.wjy.file;

/**
 * 文件传输
 */
public interface FileTransfer {

    public void fileTransfer();
}
